/* ==========================================================================
 * IARA COSTA — MODA & ACESSÓRIOS
 * loja.js — Interações da loja feminina (extensão do Bloco A)
 * --------------------------------------------------------------------------
 * Carregamento .......... <script src="assets/js/loja.js" defer></script>
 * Dependências .......... ZERO. Vanilla ES2019+, sem jQuery.
 * --------------------------------------------------------------------------
 * O QUE ESTE ARQUIVO FAZ (progressive enhancement — tudo funciona sem JS):
 *   1. Sacola persistente em localStorage (adicionar, remover, quantidades)
 *   2. Contadores do cabeçalho (sacola + desejos) sincronizados
 *   3. Mini-sacola (drawer lateral) com resumo e frete grátis R$ 299
 *   4. Lista de desejos (corações) persistente em localStorage
 *   5. Cupom de desconto (demo: BEMVINDA10 = 10%)
 *   6. Simulação de frete por CEP (faixas demo por região)
 *   7. Checkout: máscaras leves, resumo dinâmico e confirmação de pedido
 *   8. Toast de confirmação acessível (role="status")
 * ========================================================================== */
(function () {
  'use strict';

  var STORE_KEY = 'iara-sacola-v1';
  var WISH_KEY = 'iara-desejos-v1';
  var FRETE_GRATIS = 299;
  var CUPONS = { BEMVINDA10: 0.10, ATELIE15: 0.15 };

  /* Catálogo demo (espelha os produtos das páginas estáticas) */
  var CATALOGO = {
    'blusa-linho-terracota': { nome: 'Blusa de Linho Terracota',   cat: 'Blusas & Camisas', preco: 348.00, img: 'assets/img/blusa-terracota.jpg' },
    'vestido-midi-salvia': { nome: 'Vestido Midi Sálvia',        cat: 'Vestidos',          preco: 596.00, img: 'assets/img/vestido-salvia.jpg' },
    'vestido-longo-cerrado': { nome: 'Vestido Longo Cerrado',      cat: 'Vestidos',          preco: 684.00, img: 'assets/img/vestido-cerrado.jpg' },
    'vestido-curto-terra': { nome: 'Vestido Curto Terra',        cat: 'Vestidos',          preco: 429.00, img: 'assets/img/vestido-terra.jpg' },
    'camisa-linho-branca': { nome: 'Camisa Branca de Linho',     cat: 'Blusas & Camisas',  preco: 389.00, img: 'assets/img/camisa-branca.jpg' },
    'cropped-tricot-areia': { nome: 'Cropped de Tricot Areia',    cat: 'Blusas & Camisas',  preco: 249.00, img: 'assets/img/cropped-tricot.jpg' },
    'saia-linho-cru': { nome: 'Saia Midi de Linho Cru',     cat: 'Saias',             preco: 312.00, img: 'assets/img/saia-cru.jpg' },
    'saia-plissada-caramelo': { nome: 'Saia Plissada Caramelo',     cat: 'Saias',             preco: 379.00, img: 'assets/img/saia-cru.jpg' },
    'calca-pantalona-salvia': { nome: 'Calça Pantalona Sálvia',     cat: 'Calças',            preco: 459.00, img: 'assets/img/pantalona-salvia.jpg' },
    'calca-alfaiataria-carvao': { nome: 'Calça de Alfaiataria Carvão',cat: 'Calças',            preco: 499.00, img: 'assets/img/pantalona-salvia.jpg' },
    'blazer-linho-areia': { nome: 'Blazer de Linho Areia',      cat: 'Terceiras Peças',   preco: 789.00, img: 'assets/img/blazer-areia.jpg' },
    'kimono-fluido': { nome: 'Kimono Fluido Estampado',    cat: 'Terceiras Peças',   preco: 549.00, img: 'assets/img/kimono-fluido.jpg' },
    'colar-ceramica': { nome: 'Colar de Cerâmica',          cat: 'Acessórios',        preco: 189.00, img: 'assets/img/colar-ceramica.jpg' },
    'brinco-argila': { nome: 'Brinco de Argila Torneado',  cat: 'Acessórios',        preco: 149.00, img: 'assets/img/brinco-argila.jpg' },
    'lenco-algodao': { nome: 'Lenço de Algodão Tingido',   cat: 'Acessórios',        preco: 129.00, img: 'assets/img/lenco-algodao.jpg' },
    'bolsa-palha': { nome: 'Bolsa Artesanal em Palha',   cat: 'Bolsas',            preco: 429.00, img: 'assets/img/bolsa-palha.jpg' },
    'bolsa-tote-crua': { nome: 'Bolsa Tote Lona Crua',       cat: 'Bolsas',            preco: 375.00, img: 'assets/img/bolsa-palha.jpg' },
    'sandalia-couro': { nome: 'Sandália de Couro Natural',  cat: 'Calçados',          preco: 389.00, img: 'assets/img/sandalia-couro.jpg' }
  };

  /* ------------------------------------------------------------------------ */
  function moeda(valor) {
    return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }
  function ler(chave, padrao) {
    try {
      var raw = window.localStorage.getItem(chave);
      return raw ? JSON.parse(raw) : padrao;
    } catch (e) { return padrao; }
  }
  function salvar(chave, valor) {
    try { window.localStorage.setItem(chave, JSON.stringify(valor)); } catch (e) {}
  }
  function totalQtd(sacola) {
    return Object.keys(sacola).reduce(function (acc, id) {
      return acc + (parseInt(sacola[id].qtd, 10) || 0);
    }, 0);
  }
  function subtotal(sacola) {
    return Object.keys(sacola).reduce(function (acc, id) {
      var item = CATALOGO[id];
      if (!item) { return acc; }
      return acc + item.preco * (parseInt(sacola[id].qtd, 10) || 0);
    }, 0);
  }

  /* ------------------------------------------------------------------------ */
  /* Seed demo: na primeira visita, a sacola traz 2 peças (igual ao HTML      */
  /* estático e ao contador "2" do cabeçalho do template original)            */
  /* ------------------------------------------------------------------------ */
  function seedDemo() {
    try {
      if (window.localStorage.getItem(STORE_KEY) === null) {
        salvar(STORE_KEY, {
          'blusa-linho-terracota': { qtd: 1, varia: 'terracota · M' },
          'vestido-midi-salvia': { qtd: 1, varia: 'sálvia · M' }
        });
      }
      if (window.localStorage.getItem(WISH_KEY) === null) {
        salvar(WISH_KEY, ['colar-ceramica', 'bolsa-palha']);
      }
    } catch (e) {}
  }

  /* ------------------------------------------------------------------------ */
  /* Toast acessível                                                          */
  /* ------------------------------------------------------------------------ */
  var toastTimer = null;
  function toast(html) {
    var el = document.querySelector('[data-iara-toast]');
    if (!el) { return; }
    el.innerHTML = html;
    el.classList.add('is-visible');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () {
      el.classList.remove('is-visible');
    }, 3600);
  }

  /* ------------------------------------------------------------------------ */
  /* Contadores do cabeçalho                                                  */
  /* ------------------------------------------------------------------------ */
  function syncContadores() {
    var sacola = ler(STORE_KEY, {});
    var desejos = ler(WISH_KEY, []);
    var qtd = totalQtd(sacola);
    document.querySelectorAll('[data-iara-cart-count]').forEach(function (el) {
      el.textContent = String(qtd);
      el.style.display = qtd > 0 ? '' : '';
    });
    document.querySelectorAll('[data-iara-wish-count]').forEach(function (el) {
      el.textContent = String(desejos.length);
    });
    document.querySelectorAll('[data-iara-wish]').forEach(function (btn) {
      var id = btn.getAttribute('data-iara-wish');
      btn.setAttribute('aria-pressed', desejos.indexOf(id) >= 0 ? 'true' : 'false');
    });
  }

  /* ------------------------------------------------------------------------ */
  /* Desejos                                                                  */
  /* ------------------------------------------------------------------------ */
  function initDesejos() {
    document.addEventListener('click', function (ev) {
      var btn = ev.target.closest ? ev.target.closest('[data-iara-wish]') : null;
      if (!btn) { return; }
      ev.preventDefault();
      var id = btn.getAttribute('data-iara-wish');
      var desejos = ler(WISH_KEY, []);
      var ix = desejos.indexOf(id);
      if (ix >= 0) {
        desejos.splice(ix, 1);
        toast('Removido dos desejos.');
      } else {
        desejos.push(id);
        var nome = (CATALOGO[id] && CATALOGO[id].nome) || 'Peça';
        toast('<strong>' + nome + '</strong> salvo nos desejos. <a href="desejos.html">Ver lista</a>');
      }
      salvar(WISH_KEY, desejos);
      syncContadores();
    });
  }

  /* ------------------------------------------------------------------------ */
  /* Sacola: adicionar / remover / quantidades                                */
  /* ------------------------------------------------------------------------ */
  function addSacola(id, qtd, varia) {
    var sacola = ler(STORE_KEY, {});
    if (!sacola[id]) { sacola[id] = { qtd: 0, varia: varia || '' }; }
    sacola[id].qtd = Math.min(10, (parseInt(sacola[id].qtd, 10) || 0) + (qtd || 1));
    if (varia) { sacola[id].varia = varia; }
    salvar(STORE_KEY, sacola);
    syncContadores();
    renderMiniSacola();
    return sacola;
  }

  function initSacola() {
    /* Botões "Adicionar à sacola" com data-iara-add="id-produto" */
    document.addEventListener('click', function (ev) {
      var btn = ev.target.closest ? ev.target.closest('[data-iara-add]') : null;
      if (!btn) { return; }
      ev.preventDefault();
      var id = btn.getAttribute('data-iara-add');
      var item = CATALOGO[id];
      if (!item) { return; }
      addSacola(id, 1, '');
      toast('<strong>' + item.nome + '</strong> na sacola. <a href="carrinho.html">Ver sacola</a>');
      openDrawer();
    });

    /* Formulário do produto único (produto.html) */
    var form = document.querySelector('[data-iara-add-form]');
    if (form) {
      form.addEventListener('submit', function (ev) {
        ev.preventDefault();
        var id = form.getAttribute('data-iara-add-form') || 'blusa-linho-terracota';
        var qtdInput = form.querySelector('input[name="quantity"]');
        var qtd = qtdInput ? (parseInt(qtdInput.value, 10) || 1) : 1;
        var cor = form.querySelector('input[name="iara-cor"]:checked');
        var tam = document.querySelector('input[name="iara-tam"]:checked');
        var varia = [
          cor ? cor.value : '',
          tam ? tam.value.toUpperCase() : ''
        ].filter(Boolean).join(' · ');
        var item = CATALOGO[id];
        addSacola(id, qtd, varia);
        toast('<strong>' + (item ? item.nome : 'Peça') + '</strong> na sacola. <a href="carrinho.html">Ver sacola</a>');
        openDrawer();
      });
    }

    /* Página do carrinho: remover item */
    document.addEventListener('click', function (ev) {
      var btn = ev.target.closest ? ev.target.closest('[data-iara-remove]') : null;
      if (!btn) { return; }
      ev.preventDefault();
      var id = btn.getAttribute('data-iara-remove');
      var sacola = ler(STORE_KEY, {});
      delete sacola[id];
      salvar(STORE_KEY, sacola);
      syncContadores();
      var row = btn.closest('[data-iara-row]');
      if (row && row.parentNode) { row.parentNode.removeChild(row); }
      renderResumoCarrinho();
      renderMiniSacola();
      toast('Peça removida da sacola.');
    });

    /* Página do carrinho: quantidade */
    document.addEventListener('change', function (ev) {
      var input = ev.target && ev.target.matches ? ev.target : null;
      if (!input || !input.matches('[data-iara-cart-qty]')) { return; }
      var id = input.getAttribute('data-iara-cart-qty');
      var sacola = ler(STORE_KEY, {});
      var qtd = Math.min(10, Math.max(1, parseInt(input.value, 10) || 1));
      input.value = String(qtd);
      if (sacola[id]) { sacola[id].qtd = qtd; salvar(STORE_KEY, sacola); }
      syncContadores();
      renderResumoCarrinho();
      renderMiniSacola();
    });
  }

  /* ------------------------------------------------------------------------ */
  /* Mini-sacola (drawer)                                                     */
  /* ------------------------------------------------------------------------ */
  var lastDrawerFocus = null;
  function drawerEls() {
    return {
      drawer: document.querySelector('[data-iara-drawer]'),
      backdrop: document.querySelector('[data-iara-drawer-backdrop]')
    };
  }
  function openDrawer() {
    var els = drawerEls();
    if (!els.drawer) { return; }
    lastDrawerFocus = document.activeElement;
    els.drawer.hidden = false;
    if (els.backdrop) { els.backdrop.hidden = false; }
    void els.drawer.offsetWidth;
    els.drawer.classList.add('is-open');
    if (els.backdrop) { els.backdrop.classList.add('is-open'); }
    document.body.classList.add('iara-menu-open');
    renderMiniSacola();
    var close = els.drawer.querySelector('[data-iara-drawer-close]');
    if (close) { close.focus({ preventScroll: true }); }
  }
  function closeDrawer() {
    var els = drawerEls();
    if (!els.drawer || els.drawer.hidden) { return; }
    els.drawer.classList.remove('is-open');
    if (els.backdrop) { els.backdrop.classList.remove('is-open'); }
    document.body.classList.remove('iara-menu-open');
    window.setTimeout(function () {
      els.drawer.hidden = true;
      if (els.backdrop) { els.backdrop.hidden = true; }
      if (lastDrawerFocus && document.contains(lastDrawerFocus)) {
        lastDrawerFocus.focus({ preventScroll: true });
      }
    }, 260);
  }
  function renderMiniSacola() {
    var els = drawerEls();
    if (!els.drawer) { return; }
    var body = els.drawer.querySelector('[data-iara-drawer-body]');
    var totalEl = els.drawer.querySelector('[data-iara-drawer-total]');
    var prog = els.drawer.querySelector('[data-iara-ship-fill]');
    var progText = els.drawer.querySelector('[data-iara-ship-text]');
    var sacola = ler(STORE_KEY, {});
    var ids = Object.keys(sacola).filter(function (id) { return CATALOGO[id]; });
    var sub = subtotal(sacola);

    if (!ids.length) {
      body.innerHTML = '<div class="iara-empty"><h2>Sua sacola está vazia</h2>' +
        '<p>Que tal começar pelos vestidos em linho, as peças mais amadas do ateliê?</p></div>';
    } else {
      body.innerHTML = '<div class="iara-mini-items">' + ids.map(function (id) {
        var item = CATALOGO[id];
        var qtd = sacola[id].qtd;
        var varia = sacola[id].varia ? ' · ' + sacola[id].varia : '';
        return '<div class="iara-mini-item">' +
          '<img class="iara-mini-item__thumb" src="' + item.img + '" alt="" width="56" height="70" loading="lazy" ' +
          'onerror="this.onerror=null;this.src=\'https://placehold.co/200x250/eee9e1/625a52?text=' + encodeURIComponent(item.nome.split(' ').slice(0, 2).join(' ')) + '\'">' +
          '<div><strong>' + item.nome + '</strong><p>Qtd ' + qtd + varia + '</p></div>' +
          '<span class="iara-mini-item__price">' + moeda(item.preco * qtd) + '</span></div>';
      }).join('') + '</div>';
    }
    if (totalEl) { totalEl.textContent = moeda(sub); }
    if (prog && progText) {
      var pct = Math.min(100, Math.round((sub / FRETE_GRATIS) * 100));
      prog.style.width = pct + '%';
      progText.textContent = sub >= FRETE_GRATIS
        ? 'Você ganhou frete grátis para todo o Brasil.'
        : 'Faltam ' + moeda(FRETE_GRATIS - sub) + ' para o frete grátis.';
    }
  }
  function initDrawer() {
    document.addEventListener('click', function (ev) {
      var open = ev.target.closest ? ev.target.closest('[data-iara-drawer-open]') : null;
      var close = ev.target.closest ? ev.target.closest('[data-iara-drawer-close]') : null;
      var backdrop = ev.target.closest ? ev.target.closest('[data-iara-drawer-backdrop]') : null;
      if (open) { ev.preventDefault(); openDrawer(); }
      if (close || backdrop) { ev.preventDefault(); closeDrawer(); }
    });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape' || ev.key === 'Esc') { closeDrawer(); }
    });
  }

  /* ------------------------------------------------------------------------ */
  /* Resumo do carrinho + cupom + frete                                       */
  /* ------------------------------------------------------------------------ */
  var cupomAtivo = null;
  function fretePorSubtotal(sub) {
    if (sub >= FRETE_GRATIS || sub === 0) { return 0; }
    return 24.90;
  }
  function renderResumoCarrinho() {
    var sacola = ler(STORE_KEY, {});
    var sub = subtotal(sacola);
    var desconto = cupomAtivo ? sub * CUPONS[cupomAtivo] : 0;
    var frete = fretePorSubtotal(sub - desconto);
    var total = Math.max(0, sub - desconto + frete);

    var set = function (sel, txt) {
      document.querySelectorAll(sel).forEach(function (el) { el.textContent = txt; });
    };
    set('[data-iara-subtotal]', moeda(sub));
    set('[data-iara-desconto]', desconto > 0 ? '−' + moeda(desconto) : moeda(0));
    set('[data-iara-frete]', frete === 0 ? (sub > 0 ? 'Grátis' : moeda(0)) : moeda(frete));
    set('[data-iara-total]', moeda(total));
    var pix = total * 0.95;
    set('[data-iara-pix]', moeda(pix));

    var fill = document.querySelector('[data-iara-cart-ship-fill]');
    var txt = document.querySelector('[data-iara-cart-ship-text]');
    if (fill && txt) {
      var base = sub - desconto;
      fill.style.width = Math.min(100, Math.round((base / FRETE_GRATIS) * 100)) + '%';
      txt.textContent = base >= FRETE_GRATIS
        ? 'Você ganhou frete grátis para todo o Brasil.'
        : 'Faltam ' + moeda(FRETE_GRATIS - base) + ' para o frete grátis.';
    }
    var parcela = document.querySelector('[data-iara-parcela]');
    if (parcela) {
      parcela.textContent = total > 0
        ? 'em até 6x de ' + moeda(total / 6) + ' sem juros'
        : '';
    }
  }
  function initCupom() {
    var form = document.querySelector('[data-iara-cupom-form]');
    if (!form) { return; }
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var input = form.querySelector('input');
      var code = input ? input.value.trim().toUpperCase() : '';
      var msg = document.querySelector('[data-iara-cupom-msg]');
      if (CUPONS[code]) {
        cupomAtivo = code;
        if (msg) { msg.textContent = 'Cupom ' + code + ' aplicado: ' + Math.round(CUPONS[code] * 100) + '% de desconto.'; }
        toast('Cupom <strong>' + code + '</strong> aplicado.');
      } else {
        cupomAtivo = null;
        if (msg) { msg.textContent = code ? 'Cupom não reconhecido. Tente BEMVINDA10.' : 'Digite um cupom para aplicar.'; }
      }
      renderResumoCarrinho();
    });
  }
  function initFrete() {
    var form = document.querySelector('[data-iara-frete-form]');
    if (!form) { return; }
    var input = form.querySelector('input');
    if (input) {
      input.addEventListener('input', function () {
        var d = input.value.replace(/\D/g, '').slice(0, 8);
        input.value = d.length > 5 ? d.slice(0, 5) + '-' + d.slice(5) : d;
      });
    }
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var msg = document.querySelector('[data-iara-frete-msg]');
      var cep = input ? input.value.replace(/\D/g, '') : '';
      if (cep.length !== 8) {
        if (msg) { msg.textContent = 'Digite um CEP válido com 8 números.'; }
        return;
      }
      var sacola = ler(STORE_KEY, {});
      var sub = subtotal(sacola);
      if (sub >= FRETE_GRATIS) {
        if (msg) { msg.textContent = 'Para ' + input.value + ': frete GRÁTIS (PAC 4–7 dias úteis · SEDEX 2–4 dias úteis).'; }
      } else {
        if (msg) { msg.textContent = 'Para ' + input.value + ': PAC R$ 24,90 (4–7 dias úteis) · SEDEX R$ 39,90 (2–4 dias úteis).'; }
      }
    });
  }

  /* ------------------------------------------------------------------------ */
  /* Checkout                                                                 */
  /* ------------------------------------------------------------------------ */
  function initCheckout() {
    var form = document.querySelector('[data-iara-checkout]');
    if (!form) { return; }

    /* Máscaras leves */
    var cep = form.querySelector('#iara-co-cep');
    if (cep) {
      cep.addEventListener('input', function () {
        var d = cep.value.replace(/\D/g, '').slice(0, 8);
        cep.value = d.length > 5 ? d.slice(0, 5) + '-' + d.slice(5) : d;
      });
    }
    var tel = form.querySelector('#iara-co-tel');
    if (tel) {
      tel.addEventListener('input', function () {
        var d = tel.value.replace(/\D/g, '').slice(0, 11);
        if (d.length > 10) { tel.value = '(' + d.slice(0, 2) + ') ' + d.slice(2, 7) + '-' + d.slice(7); }
        else if (d.length > 6) { tel.value = '(' + d.slice(0, 2) + ') ' + d.slice(2, 6) + '-' + d.slice(6); }
        else if (d.length > 2) { tel.value = '(' + d.slice(0, 2) + ') ' + d.slice(2); }
        else { tel.value = d; }
      });
    }
    var cartao = form.querySelector('#iara-co-numero');
    if (cartao) {
      cartao.addEventListener('input', function () {
        var d = cartao.value.replace(/\D/g, '').slice(0, 16);
        cartao.value = d.replace(/(\d{4})(?=\d)/g, '$1 ');
      });
    }
    var val = form.querySelector('#iara-co-validade');
    if (val) {
      val.addEventListener('input', function () {
        var d = val.value.replace(/\D/g, '').slice(0, 4);
        val.value = d.length > 2 ? d.slice(0, 2) + '/' + d.slice(2) : d;
      });
    }

    /* Alterna campos do cartão conforme o meio de pagamento */
    var pays = form.querySelectorAll('input[name="pagamento"]');
    var cardBox = form.querySelector('[data-iara-card-fields]');
    var syncPay = function () {
      var checked = form.querySelector('input[name="pagamento"]:checked');
      var isCard = checked && checked.value === 'cartao';
      if (cardBox) { cardBox.hidden = !isCard; }
      if (cardBox) {
        cardBox.querySelectorAll('input, select').forEach(function (f) {
          if (isCard) { f.setAttribute('required', 'required'); }
          else { f.removeAttribute('required'); }
        });
      }
    };
    pays.forEach(function (p) { p.addEventListener('change', syncPay); });
    syncPay();

    /* Confirmação demo */
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }
      var numero = 'IC' + Math.floor(100000 + Math.random() * 900000);
      var ok = document.querySelector('[data-iara-order-success]');
      var wrap = document.querySelector('[data-iara-checkout-wrap]');
      if (ok && wrap) {
        var numEl = ok.querySelector('[data-iara-order-number]');
        if (numEl) { numEl.textContent = '#' + numero; }
        wrap.hidden = true;
        ok.hidden = false;
        ok.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      try { window.localStorage.removeItem(STORE_KEY); } catch (e) {}
      syncContadores();
      renderMiniSacola();
      toast('Pedido <strong>#' + numero + '</strong> confirmado. Obrigada por comprar no ateliê!');
    });
  }

  /* ------------------------------------------------------------------------ */
  /* Bootstrap                                                                */
  /* ------------------------------------------------------------------------ */
  function safeInit(name, fn) {
    try { fn(); }
    catch (error) {
      if (window.console && console.warn) {
        console.warn('[iara-loja] "' + name + '" não foi inicializado:', error);
      }
    }
  }
  function init() {
    safeInit('seed', seedDemo);
    safeInit('contadores', syncContadores);
    safeInit('desejos', initDesejos);
    safeInit('sacola', initSacola);
    safeInit('drawer', initDrawer);
    safeInit('resumo', renderResumoCarrinho);
    safeInit('cupom', initCupom);
    safeInit('frete', initFrete);
    safeInit('checkout', initCheckout);
    safeInit('mini-sacola', renderMiniSacola);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
