/* ==========================================================================
 * IARA COSTA — MODA & ACESSÓRIOS
 * header.js — Comportamento do cabeçalho (Bloco A · validação visual)
 * --------------------------------------------------------------------------
 * Carregamento .......... <script src="assets/js/header.js" defer></script>
 * Dependências .......... ZERO. Vanilla ES2019+, sem jQuery
 *                         (requisito de performance da §7 do prompt).
 * Arquivo de referência .. Iara Costa — Identidade Visual v1.0.0
 * --------------------------------------------------------------------------
 * O QUE ESTE ARQUIVO FAZ (e nada além disso):
 *   1. Alterna o painel de navegação mobile (hambúrguer)
 *   2. Fecha com ESC
 *   3. Trap de focus enquanto o painel está aberto (ciclo Tab / Shift+Tab)
 *   4. Devolve o foco ao botão de origem ao fechar
 *   5. Mantém aria-expanded / aria-hidden / inert coerentes
 *   6. Bloqueia a rolagem do body com o painel aberto
 *   7. Modalidade de entrada "keyboard" → reforço de focus-visible
 *   8. Fecha o painel ao cruzar o breakpoint de 720px (≤2.5 do dossiê)
 *   9. Aperfeiçoamentos opcionais: seletor de quantidade do produto único
 *      e miniaturas da galeria (ambos com fallback 100% CSS sem JS)
 *
 * ACESSIBILIDADE (§6):
 *   - Navegação 100% por teclado (Tab, Shift+Tab, Enter, Space, ESC)
 *   - Nenhuma armadilha de foco quando o painel está FECHADO
 *   - Foco sempre visível via :focus-visible (CSS) + data-iara-nav (JS)
 * ========================================================================== */
(function () {
  'use strict';

  /* ------------------------------------------------------------------------
   * 0. Marca de "JS ativo" (fallback progressivo)
   * O CSS esconde o hambúrguer quando html[data-iara-js="off"]. O HTML já
   * define "on" por um script inline de 1 linha no <head> (evita flash);
   * esta linha é apenas uma rede de segurança caso o inline seja removido.
   * ---------------------------------------------------------------------- */
  document.documentElement.setAttribute('data-iara-js', 'on');

  /* Seletores focáveis válidos dentro do painel (ordem do DOM) */
  var FOCUSABLE = [
    'a[href]',
    'area[href]',
    'button:not([disabled])',
    'input:not([disabled]):not([type="hidden"])',
    'select:not([disabled])',
    'textarea:not([disabled])',
    'iframe',
    'audio[controls]',
    'video[controls]',
    '[contenteditable]:not([contenteditable="false"])',
    '[tabindex]:not([tabindex="-1"])'
  ].join(',');

  /* ------------------------------------------------------------------------
   * 1. Modalidade de entrada: teclado × ponteiro
   * O CSS :focus-visible já resolve na maioria dos navegadores; a marca no
   * <html> garante o mesmo anel de foco em navegadores/engines mais antigas
   * (requisito explícito do Bloco A: "focus-visible").
   * ---------------------------------------------------------------------- */
  function initInputModality() {
    var root = document.documentElement;
    var showKeyboard = function () { root.setAttribute('data-iara-nav', 'keyboard'); };
    var hideKeyboard = function () { root.setAttribute('data-iara-nav', 'pointer'); };

    root.setAttribute('data-iara-nav', 'pointer');

    window.addEventListener('keydown', function (event) {
      if (event.key === 'Tab' || event.key === 'Escape') { showKeyboard(); }
    }, true);

    window.addEventListener('mousedown', hideKeyboard, true);
    window.addEventListener('touchstart', hideKeyboard, { capture: true, passive: true });
  }

  /* ------------------------------------------------------------------------
   * 2. Painel de navegação mobile
   * ---------------------------------------------------------------------- */
  function initMobileNav() {
    var toggle = document.querySelector('[data-iara-menu-toggle]');
    var panel = document.querySelector('[data-iara-menu]');
    var backdrop = document.querySelector('[data-iara-menu-backdrop]');
    if (!toggle || !panel) { return; }

    var closeTriggers = panel.querySelectorAll('[data-iara-menu-close]');
    var lastFocused = null;
    var isOpen = false;

    /* Utilitários ---------------------------------------------------------- */

    /* Visibilidade com "fail-open": na dúvida, o elemento CONTINUA focável.
       Isso é deliberado — excluir por engano um item visível quebraria o
       acesso por teclado (falha grave), enquanto incluir um item invisível
       custa apenas um Tab a mais (falha leve).
       A checagem usa estilo computado (confiável) e só cai para medidas de
       layout quando getComputedStyle não estiver disponível. */
    function isReachable(node) {
      if (!node || node.hidden) { return false; }
      if (node.getAttribute('aria-hidden') === 'true') { return false; }
      if (parseInt(node.getAttribute('tabindex'), 10) < 0) { return false; }

      if (typeof window.getComputedStyle === 'function') {
        var cs = window.getComputedStyle(node);
        if (cs) {
          if (cs.display === 'none' || cs.visibility === 'hidden' || cs.visibility === 'collapse') {
            return false;
          }
          return true; /* o estilo computado confirma que o nó é renderizado */
        }
      }
      return !!(node.offsetWidth || node.offsetHeight ||
                (node.getClientRects && node.getClientRects().length));
    }

    function focusableItems() {
      var nodes = panel.querySelectorAll(FOCUSABLE);
      return Array.prototype.filter.call(nodes, isReachable);
    }

    function lockScroll(lock) {
      document.body.classList.toggle('iara-menu-open', lock);
      /* Compensação de largura da barra de rolagem [DERIVADO do sistema] */
      if (lock) {
        var gap = window.innerWidth - document.documentElement.clientWidth;
        document.body.style.paddingRight = gap > 0 ? gap + 'px' : '';
      } else {
        document.body.style.paddingRight = '';
      }
    }

    function setExpanded(state) {
      toggle.setAttribute('aria-expanded', state ? 'true' : 'false');
      toggle.setAttribute('aria-label', state ? 'Fechar menu' : 'Abrir menu');
    }

    /* Abertura / fechamento ----------------------------------------------- */

    function openPanel(returnFocusTo) {
      if (isOpen) { return; }
      isOpen = true;
      lastFocused = returnFocusTo || document.activeElement;

      panel.hidden = false;
      if (backdrop) {
        /* O atributo hidden tem display:none na folha do navegador: é preciso
           removê-lo, não basta trocar a classe, senão o backdrop não aparece. */
        backdrop.hidden = false;
      }
      /* Força o recálculo de estilo antes da transição para animar a entrada */
      void panel.offsetWidth;
      panel.classList.add('is-open');
      panel.setAttribute('aria-hidden', 'false');
      if (backdrop) { backdrop.classList.add('is-open'); }

      setExpanded(true);
      lockScroll(true);
      panel.focus({ preventScroll: true });
    }

    function closePanel(options) {
      if (!isOpen) { return; }
      var opts = options || {};
      isOpen = false;

      panel.classList.remove('is-open');
      panel.setAttribute('aria-hidden', 'true');
      if (backdrop) { backdrop.classList.remove('is-open'); }
      setExpanded(false);
      lockScroll(false);

      var finalize = function () {
        /* Se o painel foi reaberto antes da transição terminar, não esconder */
        if (isOpen) { return; }
        panel.hidden = true;
        panel.removeEventListener('transitionend', finalize);
        if (backdrop) { backdrop.hidden = true; } /* volta ao estado inicial do HTML */
      };
      /* hidden só depois da transição (evita "pulo" visual); fallback de tempo */
      panel.addEventListener('transitionend', finalize);
      window.setTimeout(finalize, 320);

      if (opts.restoreFocus !== false) {
        var target = lastFocused && document.contains(lastFocused) ? lastFocused : toggle;
        window.setTimeout(function () { target.focus({ preventScroll: true }); }, 0);
      }
    }

    /* Eventos ------------------------------------------------------------- */

    toggle.addEventListener('click', function (event) {
      event.preventDefault();
      if (isOpen) { closePanel(); } else { openPanel(toggle); }
    });

    Array.prototype.forEach.call(closeTriggers, function (trigger) {
      trigger.addEventListener('click', function (event) {
        event.preventDefault();
        closePanel();
      });
    });

    if (backdrop) {
      backdrop.addEventListener('click', function () { closePanel(); });
    }

    /* Fecha ao clicar em um link do painel (navegação real acontece em seguida) */
    panel.addEventListener('click', function (event) {
      var link = event.target.closest && event.target.closest('a[href]');
      if (link) { closePanel({ restoreFocus: false }); }
    });

    /* Teclado: ESC fecha e cicla o foco dentro do painel ------------------ */
    document.addEventListener('keydown', function (event) {
      if (!isOpen) { return; }

      if (event.key === 'Escape' || event.key === 'Esc') {
        event.preventDefault();
        closePanel();
        return;
      }

      if (event.key !== 'Tab') { return; }

      var items = focusableItems();
      if (!items.length) { event.preventDefault(); panel.focus({ preventScroll: true }); return; }

      var first = items[0];
      var last = items[items.length - 1];
      var active = document.activeElement;

      /* Foco fora do painel (ex.: clique anterior na página) → trazer para dentro */
      if (!panel.contains(active)) {
        event.preventDefault();
        (event.shiftKey ? last : first).focus();
        return;
      }

      if (event.shiftKey && (active === first || active === panel)) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && active === last) {
        event.preventDefault();
        first.focus();
      }
    });

    /* Ao cruzar o breakpoint mobile (720px) o painel não deve ficar preso ---- */
    var mobileQuery = typeof window.matchMedia === 'function'
      ? window.matchMedia('(max-width: 720px)')
      : null;
    var onBreakpointChange = function (event) {
      if (!event.matches) { closePanel({ restoreFocus: false }); }
    };
    if (mobileQuery && typeof mobileQuery.addEventListener === 'function') {
      mobileQuery.addEventListener('change', onBreakpointChange);
    } else if (mobileQuery && typeof mobileQuery.addListener === 'function') {
      mobileQuery.addListener(onBreakpointChange); /* Safari < 14 */
    }

    /* O clique no backdrop fora do painel não deve borbulhar para a página ---- */
    if (backdrop) {
      backdrop.addEventListener('keydown', function (event) { event.preventDefault(); });
    }
  }

  /* ------------------------------------------------------------------------
   * 3. Seletor de quantidade (página de produto único)
   * Progressive enhancement: o input type="number" já funciona sem JS.
   * ---------------------------------------------------------------------- */
  function initQuantity() {
    var steppers = document.querySelectorAll('[data-iara-qty]');
    Array.prototype.forEach.call(steppers, function (stepper) {
      var input = stepper.querySelector('input[type="number"]');
      if (!input) { return; }

      var min = parseFloat(input.getAttribute('min') || '1');
      var max = parseFloat(input.getAttribute('max') || '99');
      var step = parseFloat(input.getAttribute('step') || '1');

      Array.prototype.forEach.call(stepper.querySelectorAll('button[data-iara-qty-step]'), function (button) {
        button.addEventListener('click', function () {
          var direction = parseInt(button.getAttribute('data-iara-qty-step'), 10) || 1;
          var current = parseFloat(input.value) || min;
          var next = Math.min(max, Math.max(min, current + (step * direction)));
          input.value = String(next);
          input.dispatchEvent(new Event('change', { bubbles: true })); /* WooCommerce reage */
        });
      });

      /* Sanitiza digitação manual, como o WooCommerce faz no carrinho */
      input.addEventListener('change', function () {
        var value = parseFloat(input.value);
        if (isNaN(value) || value < min) { input.value = String(min); }
        else if (value > max) { input.value = String(max); }
      });
    });
  }

  /* ------------------------------------------------------------------------
   * 4. Miniaturas da galeria (produto único)
   * Sem JS, a troca já funciona por CSS (:checked). Aqui apenas sincronizamos
   * o rótulo acessível da imagem exibida — reforço sem quebrar o fallback.
   * ---------------------------------------------------------------------- */
  function initGallery() {
    var galleries = document.querySelectorAll('[data-iara-gallery]');
    Array.prototype.forEach.call(galleries, function (gallery) {
      var radios = gallery.querySelectorAll('input[type="radio"][name]');
      if (!radios.length) { return; }

      var sync = function () {
        var checked = gallery.querySelector('input[type="radio"]:checked');
        if (!checked) { return; }
        var label = gallery.querySelector('[for="' + checked.id + '"]');
        var stage = gallery.querySelector('[data-iara-gallery-stage]');
        if (stage && label) {
          var index = label.getAttribute('data-iara-index') || '';
          stage.setAttribute('aria-label', 'Imagem ' + index + ' de ' + radios.length);
        }
      };

      Array.prototype.forEach.call(radios, function (radio) {
        radio.addEventListener('change', sync);
      });
      sync();
    });
  }

  /* ------------------------------------------------------------------------
   * 5. Bootstrap
   * Cada melhoria é iniciada em isolamento: se uma falhar, as demais
   * continuam funcionando (o cabeçalho nunca fica "meio inicializado").
   * ---------------------------------------------------------------------- */
  function safeInit(name, fn) {
    try {
      fn();
    } catch (error) {
      /* Falha silenciosa e contida: nenhum recurso essencial depende do JS —
         sem ele a navegação segue acessível pelo painel/âncoras do HTML. */
      if (window.console && console.warn) {
        console.warn('[iara-header] melhoria "' + name + '" não foi inicializada:', error);
      }
    }
  }

  function init() {
    safeInit('input-modality', initInputModality);
    safeInit('mobile-nav', initMobileNav);
    safeInit('quantity', initQuantity);
    safeInit('gallery', initGallery);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
